import { ApolloDriver, ApolloDriverConfig } from '@nestjs/apollo';
import { Module } from '@nestjs/common';
import { GraphQLModule } from '@nestjs/graphql';
import { databaseProviders } from './config/database.provider';
import { PlayerResolver } from './resolvers/player.resolver';

@Module({
  imports: [
    PlayerResolver,
    GraphQLModule.forRoot<ApolloDriverConfig>({
      driver: ApolloDriver,
      autoSchemaFile: 'schema.gql',
    }),
  ],
  providers: [
    ...databaseProviders
  ]
})
export class AppModule {}
