import { Args, Query, Resolver, } from "@nestjs/graphql";
import Player from "src/models/player.entity";

@Resolver(of => Player)
export class PlayerResolver {
    constructor(
        // private authorsService: AuthorsService,
    ) {}

    @Query(returns => Player)
    async author(@Args('id', { type: () => String }) id: number) {
        return {
            username: "Hola"
        };
    }
}