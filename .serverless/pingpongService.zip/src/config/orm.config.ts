import { UUIDExtension1653956432131 } from 'src/migrations/1653956432131-UUID_extension';
import { Player1653956468916 } from 'src/migrations/1653956468916-Player';
import { DataSource, DataSourceOptions } from 'typeorm';

const OrmConfig: DataSourceOptions = {
  type: 'postgres',
  host: process.env.db_postgres_db_host || 'localhost',
  port: parseInt(process.env.db_postgres_db_port) || 5432,
  username: process.env.db_postgres_db_user || 'postgres',
  password: process.env.db_postgres_db_password || 'postgres',
  database: process.env.db_postgres_db_name || 'postgres',
  entities: [],
  synchronize: false,
  migrationsRun: true,
  logging: false,
  migrations: [
    UUIDExtension1653956432131,
    Player1653956468916
  ]
};

export default new DataSource(OrmConfig);